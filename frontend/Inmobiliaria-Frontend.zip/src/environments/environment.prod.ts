export const environment = {
  production: true,
  apiUrl: 'https://miapi.com/api',
};
