import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router, RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import {
  faUser,
  faLock,
  faEnvelope,
  faPhone,
  faIdCard,
  faUserTag,
  faUserPlus,
} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule, RouterModule, FontAwesomeModule],
  templateUrl: './register.html',
  styleUrl: './register.css',
})
export class RegisterComponent {
  isLoading = false;
  errorMessage = '';
  registerForm: any;
  _authService = inject(AuthService);

  // Icons
  faUser = faUser;
  faLock = faLock;
  faEnvelope = faEnvelope;
  faPhone = faPhone;
  faIdCard = faIdCard;
  faUserTag = faUserTag;
  faUserPlus = faUserPlus;

  constructor(private fb: FormBuilder, private router: Router) {
    this.registerForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.minLength(3)]],
      username: ['', [Validators.required, Validators.minLength(3)]],
      ci: ['', [Validators.required]],
      telefono: ['', [Validators.required, Validators.pattern(/^[0-9]{8,}$/)]],
      email: ['', [Validators.required, Validators.email]],
      password: [
        '',
        [
          Validators.required,
          Validators.pattern(/^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>]).{8,}$/),
        ],
      ],
    });
  }

  async onSubmit() {
    if (this.registerForm.invalid) return;

    this.isLoading = true;
    this.errorMessage = '';

    this._authService.register(this.registerForm.value).subscribe({
      next: (resp) => {
        console.log('Usuario registrado', resp);
        this.isLoading = false;
        this.router.navigate(['/login']);
      },
      error: (err) => {
        console.error('Error al registrar usuario', err);
        this.isLoading = false;
        this.errorMessage = err.message || 'Error al registrar usuario';
      },
    });
  }
}
