export interface LoginDto {
  identifier: string;
  password: string;
  rememberMe: boolean;
}